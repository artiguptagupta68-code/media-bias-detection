# Media Bias Detection - Repo (Generated)

This repository contains a Colab notebook, a synthetic dataset, and a Gradio app to run a Media Bias Detection model using SBERT embeddings + Logistic Regression.

## Files
- `news_headlines_synthetic_500.csv` - synthetic dataset (500 samples)
- `Media_Bias_Detection_Colab.ipynb` - colab notebook
- `app.py` - gradio app to serve the model
- `requirements.txt` - python dependencies
- `artifacts/` - model artifacts (generated after running the notebook)

## How to run locally
1. Clone the repo
2. Create virtualenv and install requirements:
```
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```
3. Run the notebook in Colab or run `app.py` after you have trained and saved artifacts:
```
python app.py
```
4. To deploy to GitHub Pages / Heroku / Render / Hugging Face Spaces, follow platform-specific instructions. For Hugging Face Spaces (Gradio), push this repo to a public GitHub repo and connect it to Spaces.

## To push to GitHub (example commands)
```
git init
git add .
git commit -m "Initial commit - media bias detection"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<REPO_NAME>.git
git push -u origin main
```
Note: replace `<YOUR_USERNAME>` and `<REPO_NAME>` with your details. You will need to create the repository on GitHub or use `gh` CLI to create it.