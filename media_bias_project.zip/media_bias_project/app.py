
import joblib
from sentence_transformers import SentenceTransformer
import re

clf = joblib.load('artifacts/logreg_sbert.joblib')
le = joblib.load('artifacts/label_encoder.joblib')
sbert = SentenceTransformer('all-MiniLM-L6-v2')

def clean_text(text):
    return re.sub(r'[^a-zA-Z0-9\s]', '', text.lower()).strip()

def predict(headline: str):
    emb = sbert.encode([clean_text(headline)])
    pred = clf.predict(emb)[0]
    return le.inverse_transform([pred])[0]

# Gradio app
import gradio as gr
iface = gr.Interface(fn=predict, inputs=gr.Textbox(lines=2, placeholder='Enter headline...'), outputs='text', title='Media Bias Detection')
if __name__ == '__main__':
    iface.launch(server_name='0.0.0.0', server_port=7860)
